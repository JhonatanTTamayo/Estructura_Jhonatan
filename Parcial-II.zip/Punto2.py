class DoubleLinkedLinkd2:
  class Nodo:
    #Constructor de la clase nodo
    def __init__(self, value):
      self.value = value
      self.previous_node = None
      self.next_node = None
  #Constructor de la clase DoubleLinkeLis
  def __init__(self):
    self.head = None
    self.tail = None
    self.length = 0
  
  def show_elements_punto2(self):
    array=[]
    current_node = self.head
    #Mientras si exista al menos un nodo entonces
    while(current_node != None):
      array.append(current_node.value)
      current_node = current_node.next_node
    return print(array)

  def punto2(self):
    intento1 =3
    intento2 = 3
    auxiliar1 = False
    auxiliar2 = True
    print('Lista')
    self.show_elements_punto2()
    print('Cada intento va a ser contado')
    while(intento1 !=0 or auxiliar !=False):
      print(f'Intento {intento1} fallido')
       
      intento2 = int(input('Siguiente intento'))
      verificar = self.validarNodo
      if(intento2 == verificar):
        print('Numero exitoso')
        auxiliar2 = True
        self.set(4,intento1)
      else:
        print('Intento perdido')
        intento2 -=1
    else:
      print('Exito')

    
  def set(self, index, value):
    update_node = self.get(index)
    if update_node != None:
      update_node.value = value
    else:
      return None    

  def validarNodo(self):
    