
from Punto1 import DoubleLinkedLinkd
inst_DLL = DoubleLinkedLinkd()
inst_DLL.append(2)
inst_DLL.append(5)
inst_DLL.append(10)
inst_DLL.append(17)
inst_DLL.append(26)
inst_DLL.append(37)
inst_DLL.append(50)
inst_DLL.append(65)
inst_DLL.append(82)
inst_DLL.show_elements_list()
inst_DLL.puntoBuscar()

#---------------------------------------------
print('----------Punto 2-------')
from Punto2 import DoubleLinkedLinkd2
inst_P2 = DoubleLinkedLinkd2()
inst_P2.append(1)
inst_P2.append(3)
inst_P2.append(4)
inst_P2.append(16)
inst_P2.append(23)
inst_P2.append(101)
inst_P2.append(43)