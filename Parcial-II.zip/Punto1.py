class DoubleLinkedLinkd:
  class Nodo:
    #Constructor de la clase nodo
    def __init__(self, value):
      self.value = value
      self.previous_node = None
      self.next_node = None
  #Constructor de la clase DoubleLinkeLis
  def __init__(self):
    self.head = None
    self.tail = None
    self.length = 0
  
  def show_elements_list(self):
    array=[]
    current_node = self.head
    #Mientras si exista al menos un nodo entonces
    while(current_node != None):
      array.append(current_node.value)
      current_node = current_node.next_node
    return print(array)

  def append(self, value):
    new_node = self.Nodo(value)
    if self.head == None and self.tail == None:
      self.head = new_node
      self.tail = self.head
    else:
      self.tail.next_node = new_node
      new_node.previous_node = self.tail
      self.tail = new_node
    self.length += 1
    return print(new_node.value)
    
  def validarNumero(self, value):
    arrayAux=[]
    contador = 1
    for i in range(self.length):
      contador +=2
      arrayAux.append(contador)
    validar = arrayAux[self.length-1]+ self.tail.value
    if(validar == value):
      return True
    else:
      return False
      
  def puntoBuscar(self):
    self.show_elements_list
    numero = int(input('Ingrese el valor que desea añadir:' ))
    if(self.validarNumero(numero)):
      self.append(numero)
      print('Numero agregado con exito')
    else:
      print("Valor no agregado")

  
    
  


